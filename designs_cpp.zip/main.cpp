#include <iostream>
#include <string>
#include "person"
using namespace std;
Person::Person()
{
    name = "小李";
    age = 18, height = 180, weight = 65;
    gender = "男";
    number = "110";
}
int main()
{
}